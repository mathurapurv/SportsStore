/**
 * 
 */

var triggerSearchURL =  '../data/searchResult1.json';
var triggerDetailsSearchURL  =  '../data/triggerDetailsResult1.json';

var letterTypeList = [ 
{
	label : "-- SELECT --",
	value : ""
},                      
{
	label : "CSH",
	value : "CSH"
}, {
	label : "DSC",
	value : "DSC"
}, {
	label : "COCD",
	value : "COCD"
}, {
	label : "COT",
	value : "COT"
}, {
	label : "CA",
	value : "CA"
} ];

var sourceList = [{
	label : "-- SELECT --",
	value : ""
},    
{
	label : "GFAS",
	value : "GFAS"
},
{
	label : "CO",
	value : "CO"
},
{
	label : "SONATA",
	value : "SONATA"
}
] ; 
