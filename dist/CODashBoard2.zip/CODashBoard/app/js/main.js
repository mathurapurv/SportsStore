/**
 * 
 */

$(function() {
	onDomReady();
});

function onDomReady() {
	console.log('hi There');
	// generating search trigger page 
	generateSearchTriggerDOM();
	// generating trigger details  page
	generateTriggerDetailsDOM();

	console.log('.. and we are done..')

}
