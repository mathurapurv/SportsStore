/**
 * 
 */


$(function () {
    onDomReady();
});



function onDomReady(){
	console.log('hi There') ; 
	
	
	
	
	var SearchInputParamModel = Backbone.Model.extend({
		
		
		defaults : {
			
			cdb : '',
			eventId : '',
			source : '',	
			commCode : '',
			fromDate:'',
			toDate : '',
			sourceList : ['GFAS' , 'SONATA'] , 
			commCodeList : ['COCD' , 'CSH' , 'DDS' , 'COT' , 'CA'] , 
			searchResult : []
		},
		
		
		initialize: function () {
			console.log('Initialize model ')
	       //this.on('change:original', this.onOriginalUpdated, this);
	    },
	    
	});
	
	
	
	

	
	
	
	
	var searchModel = new SearchInputParamModel();
	
	
	
	
	
	
	
	
	
	
	




	console.log('.. and we are done..')
	
	
}








