/**
 * 
 */

$(function() {
	onDomReady();
});

function onDomReady() {
	console.log('hi There');
	
	// show full page alert while data is loaded 
	showAlertModel(  "Loading Dashboard ..." )
	
	// generating search trigger page 
	generateSearchTriggerDOM();
	// generating trigger details  page
	generateTriggerDetailsDOM();
	
	// generating trigger metrices  page
	generateTriggerMetricesDOM()
	
	// generate application performance graph
	generateApplicationPerformanceMetricesDOM();
	
	// hide  full page alert after  data is loaded 
	hideAlertModel()

	console.log('.. and we are done..')

}


