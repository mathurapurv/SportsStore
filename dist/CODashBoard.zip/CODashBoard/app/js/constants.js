/**
 * 
 */

// URL for data fetching 
var triggerSearchURL =  '../data/searchResult1.json';
var triggerDetailsSearchURL  =  '../data/triggerDetailsResult1.json';
var letterSpecificTriggerDetailsURL  =  '../data/letterSpecificTriggerDistributionResult';
var applicationPerformanceDetailsURL  =  '../data/applicationPerformaceDetailsResult';





// trigger search page drop down values
var letterTypeList = ["CSH" ,  "DSC" , "COCD" , "COT" , "CA" , ];
var sourceList = ["GFAS","CO","SONATA"];


//  Utility functions 

/**
 * @param ["GFAS","CO","SONATA"]
 * @param true / false
 * @returns [{"label":"-- Select --","value":""},{"label":"GFAS","value":"GFAS"},{"label":"CO","value":"CO"},{"label":"SONATA","value":"SONATA"}]
 */
function generateDropDownListModel( options ,  includeNoneValue){
	var aggregatedList  = [];
	if(includeNoneValue){
		var jsonData = {};
		jsonData["label"] = '-- Select --';
		jsonData["value"] = '';
		aggregatedList.push(jsonData)
	}
	
	_.each(options, function(item) {
		var jsonData = {};
		jsonData["label"] = item;
		jsonData["value"] = item;
		this.push(jsonData)
	}, aggregatedList);
	console.log(JSON.stringify(aggregatedList))
	return aggregatedList;
}




/**
 * Transposes json array (2 d ) to create lists appropriate for 
 * Highcharts 
 * 
 * eg. Takes in this 
 * 
 * [  {"code" : "CSH" , "count" : 23},
	   {"code" : "COCD" , "count" : 45},
	 {"code" : "DDS" , "count" : 12},
	   {"code" : "COT" , "count" : 9},
	{"code" : "CA" , "count" : 199}
	   ]
	                                        
	 
 * and gives out this 
 * 
 * {"XaxisDataList":["CSH","COCD","DDS","COT","CA"],"YaxisDataList":[23,45,12,9,199]}
 * 
 * 	                                        
 * @param dataSet
 * @param xLabel
 * @param yLabel
 * @returns {graphDataSet }
 */
function seperateXandYaxisDatafromJSONResponse(dataSet, xLabel , yLabel){
	var XaxisDataList  = [];
	var YaxisDataList  = [];
	var graphDataSet = { "XaxisDataList" : XaxisDataList , "YaxisDataList" : YaxisDataList} ; 
	_.each(dataSet, function(datapoint) {
		this.XaxisDataList.push(datapoint[xLabel]) ; 
		this.YaxisDataList.push(datapoint[yLabel]) ;
	}, graphDataSet);
	console.log(JSON.stringify(graphDataSet))
	return graphDataSet ;
}



/**
 * @param alertString
 */
function showAlertModel(  alertString ){
	$('#alertStringDiv').html(alertString) ; 	
	$('#fullPageAlertModelDiv').modal('show') ; 
}


/**
 * 
 */
function hideAlertModel(){
	
	$('#fullPageAlertModelDiv').modal('hide') ; 
	
}





 