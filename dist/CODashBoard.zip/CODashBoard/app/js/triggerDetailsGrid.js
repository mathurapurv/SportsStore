/**
 * 
 */

function generateTriggerDetailsDOM() {
	
	var TriggerDetailsRequestInputParamModel = Backbone.Model.extend({
		defaults : {
			eventId : '',
			searchResult : []
		},

		initialize : function() {
			console.log('Initialize model ')

			this.on('change', function() {
				console.log('change TriggerDetailsRequestInputParamModel ')
			}, this);
		},
		url : triggerDetailsSearchURL,
	});
	
	

	var triggerDetailsRequestInputFields = [ {
		name : "eventId",
		label : "Event ID",
		control : "input",
		disabled : false
		}, {
			control : "button",
			label : "Submit"
	}];
	
	
	var triggerDetailsRequestInputParamModel = new TriggerDetailsRequestInputParamModel();
	
	
	var triggerDetailsSearchForm = new Backform.Form({
		el : $("#triggerDetailsSearchForm"),
		model : triggerDetailsRequestInputParamModel,
		fields : triggerDetailsRequestInputFields,
		events : {
			"submit" : function(e) {
				// prevent actual HTTP form submission
				e.preventDefault();
				triggerDetailsRequestInputParamModel.fetch({
					success : function() {
						console.log('Fetch successful ')
						
						var scoll = new TriggerDetailsResultCollection(triggerDetailsRequestInputParamModel.get('searchResult'))
						
						
						// Initialize a new Grid instance
						var triggerDetailsSearchGrid = new Backgrid.Grid({
							columns : triggerDetailsSearchColumns,
							collection : scoll
						});
						$("#triggerDetailsSearchResultGrid").empty();
						$("#triggerDetailsSearchResultGrid").append(
								triggerDetailsSearchGrid.render().el);
						
						console.log('Render complete ');
					},
					error : function(error) {
						console.log('Fetch fail ');
						alert('Unable to fetch data')
					}
				});
				return false;
			}
		}
	});
	
	triggerDetailsSearchForm.render();
	

		
	var triggerDetailsSearchColumns = [ {
		name : "status",
		label : "STATUS",
		editable : false,
		cell : "string"		
	},

	{
		name : "timestamp",
		label : "TIME",
		editable : false,
		cell : "string"
	},

	{
		name : "component",
		label : "COMPONENT",
		editable : false,
		cell : "string"
	}, ];
	
	
	var TriggerDetailsResultModel = Backbone.Model.extend({});
	
	var TriggerDetailsResultCollection = Backbone.Collection.extend({
		model : TriggerDetailsResultModel,
		initialize : function(models, options) {
		}
	});
	
}