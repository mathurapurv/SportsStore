package com.apurv.gateway;

public interface JMSPostGateway {
	
	void postToQ1(String message);

}
