package com.apurv.activator;

import org.springframework.messaging.Message;

public class PrintMessage {

	private String name;

	public PrintMessage(String name) {
		super();
		this.name = name;
	}

	public Message print(Message message) {
		System.out.println("[" + name + " "+ System.currentTimeMillis()+" ]: >> " + message.getPayload());
		return message;
	}

}
