package com.apurv.log;

import org.apache.log4j.jdbc.JDBCAppender;
import org.apache.log4j.spi.LoggingEvent;

public class DBAppender extends JDBCAppender {

	@Override
	protected String getLogStatement(LoggingEvent event) {
		String sql =  "insert into at_log values ('" + String.valueOf(event.getMessage()) + "')";
		System.out.println("sql : "+sql);
		return sql;
		// return getLayout().format(event);
	}

}
