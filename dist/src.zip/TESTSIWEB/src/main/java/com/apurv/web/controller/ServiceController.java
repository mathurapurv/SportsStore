package com.apurv.web.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.apurv.model.Customer;
import com.google.gson.Gson;


@Controller
public class ServiceController {
	
	private Map<Long, Customer> customerIndex ;
	
	
	public ServiceController(){
		
		// initialize customer index 
		Customer c ;
		Map<Long, Customer> customerIndex= new HashMap<Long, Customer>();
		for(int i=0;i<12;i++){
			c= new Customer(12l*i, "name"+i, i, true, "address"+i);
			customerIndex.put(12l*i, c);
			
		}
		this.customerIndex = customerIndex;
	}
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET ,produces = "application/json" )
	@ResponseBody
	public String index() {
		System.out.println("index() is executed!");
		return "Hello world ";
	}
	
	
	

	
	
	@RequestMapping(value = "/triggerSearch", 
			method = RequestMethod.POST ,
			produces = "application/json" )
	@ResponseBody
	public void triggerSearch(@ModelAttribute("cdb") String cdb ,
			@ModelAttribute("eventId") String eventId ,
			@ModelAttribute("source") String source ,
			@ModelAttribute("commCode") String commCode ,
			@ModelAttribute("fromDate") String fromDate ,
			@ModelAttribute("toDate") String toDate , HttpServletResponse response) throws Exception{
		
		System.out.println("cdb: " + cdb);
		System.out.println("eventId: " + eventId);
		System.out.println("source: " + source);
		System.out.println("commCode: " + commCode);
		System.out.println("fromDate: " + fromDate);
		System.out.println("toDate: " + toDate);
		
		
		
		copyFileContentsToResponse("searchResult1.json", "", response);
	}
	
	
	
	@RequestMapping(value = "/letterSpecificTriggerDistributionResult/{dayCount}", 
			method = RequestMethod.GET ,
			produces = "application/json" )
	@ResponseBody
	public void  getLetterSpecificTriggerDistributionResult(@PathVariable("dayCount") String dayCount,HttpServletResponse response){
		System.out.println("getting for daycount : "+dayCount);
		String fileName = "letterSpecificTriggerDistributionResult"+dayCount+".json";
		copyFileContentsToResponse(fileName, "", response);
		
	}
	
	
	@RequestMapping(value = "/generateLetterByEventId/{eventId}", 
			method = RequestMethod.GET ,
			produces = "application/json" )
	@ResponseBody
	public void  generateLetterByEventId(@PathVariable("eventId") String eventId,HttpServletResponse response){
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "inline filename=\"myfile.pdf\"");
		
		
		FileSystemResource resource = new FileSystemResource("F:\\eclipse-workspaces\\w1\\TESTSIWEB\\src\\main\\webapp\\app\\data\\dds-letter.pdf");
		try {
			IOUtils.copy(resource.getInputStream(), response.getOutputStream());
			response.getOutputStream().flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value = "/customerListStream", 
			method = RequestMethod.GET ,
			produces = "application/json" )
	@ResponseBody
	public void customerListStream(HttpServletResponse response) throws Exception{
		List<Customer> customerList = new ArrayList<Customer>();
		customerList.addAll(this.customerIndex .values());
		String customerListJson  = convertObjectToJSON(customerList);
		System.out.println(customerListJson);
		response.getWriter().println(customerListJson);
	}
	
	@RequestMapping(value = "/customerList", 
			method = RequestMethod.GET ,
			produces = "application/json" )
	@ResponseBody
	public String getCustomerList(HttpServletResponse response){
		List<Customer> customerList = new ArrayList<Customer>();
		customerList.addAll(this.customerIndex .values());
		String customerListJson  = convertObjectToJSON(customerList);
		System.out.println(customerListJson);
		return customerListJson;
		
	}

	
	@RequestMapping(value = "/customer/{id}", 
			method = RequestMethod.GET ,
			produces = "application/json" )
	@ResponseBody
	public String getCustomerByID(@PathVariable("id") String idStr) {
		try {
			Long id = Long.parseLong(idStr);
			Customer c = customerIndex.get(id);
			if (c != null) {
				return convertObjectToJSON(c);
			} else {
				return "Customer not found";
			}
		} catch (NumberFormatException nfe) {
			System.out.println("Passed incorrect id ");
			return "";
		}
	}
	
	private String convertObjectToJSON(Object obj){
		Gson gson = new Gson();
		return gson.toJson(obj);
	}
	
	private void copyFileContentsToResponse(String fileName , String relativePath , HttpServletResponse response){
		FileSystemResource resource = new FileSystemResource("F:\\eclipse-workspaces\\w1\\TESTSIWEB\\src\\main\\webapp\\app\\data\\"+relativePath+fileName);
		try {
			IOUtils.copy(resource.getInputStream(), response.getWriter());
			response.getWriter().flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

}
