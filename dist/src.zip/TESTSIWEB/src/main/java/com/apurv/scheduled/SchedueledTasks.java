package com.apurv.scheduled;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.support.MessageBuilder;

import com.apurv.gateway.JMSPostGateway;

public class SchedueledTasks {

	@Autowired
	JMSPostGateway gateway;
	
	@Autowired
	QueueChannel bufferedChannel;

	public void postToReplyQ() {
		System.out.println(">> posting 10 messages");
		for (int i = 0; i < 10; i++) {
			gateway.postToQ1("Msg-" + i);
		}
		System.out.println(">> posting done");
	}
	
	public void postToBufferedChannel() {
		System.out.println(">> posting 10 messages to buffered q");
		for (int i = 0; i < 10; i++) {
			bufferedChannel.send(MessageBuilder.withPayload("Msg-" + i).build());
		}
		System.out.println(">> posting done");
	}
}
