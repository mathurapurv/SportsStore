/**
 * 
 */


function generateApplicationPerformanceMetricesDOM() {
	
	

	// define model for graph data 
	var ApplicationPerformanceModel = Backbone.Model.extend({
		defaults : {
			historicalDataDayCount : 5,
			data :  {     categories: [       "CSH",       "DDS",       "COCD",       "CA",           ],     series: [       {         name: "TC",         data: [           49.9,           71.5,           106.4,                   ]       },       {         name: "MO",         data: [           83.6,           78.8,           98.5,                   ]       },       {         name: "CE",         data: [           48.9,           38.8,           39.3,                   ]       }           ]   }
		},
		initialize : function() {
			console.log('Initialize model ')
			// event handler when graph needs to be refreshed
			this.on('refreshApplicationPerformanceDataEvent', function() {
				console.log('change model1 ')
				this.refreshApplicationPerformanceData();
			}, this);
		},
		urlRoot : applicationPerformanceDetailsURL,
		
		refreshApplicationPerformanceData : function(){
			this.url = this.urlRoot + this.get('historicalDataDayCount') + '.json';
			this.fetch({
				success : function() {
					graphApplicationPerformanceView.render();
				},
				error : function(error) {
					console.log(error);
					alert('Unable to fetch data for graph')
				}
			});
		}

	});

	var graphApplicationPerformanceModel = new ApplicationPerformanceModel({});
	
	var ApplicationPerformanceGraphView = Backbone.View
			.extend({
				el : '#appPerformance1',
				initialize : function(options) {
					this.data = options.data;
				},
				render : function() {

					this.$el.highcharts({
						
						   chart: {
					            type: 'column'
					        },
					        title: {
					            text: 'Average Time Spent'
					        },
					        subtitle: {
					            text: 'Source: AT logging'
					        },
					        xAxis: {
					            categories: this.model.get('data').categories,
					            crosshair: true
					        },
					        yAxis: {
					            min: 0,
					            title: {
					                text: 'Time (ms)'
					            }
					        },
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>{point.y:.1f} ms</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					                pointPadding: 0.2,
					                borderWidth: 0
					            }
					        },
					        series: this.model.get('data').series
							
				    });
				    
				    
				}
			});

	var graphApplicationPerformanceView = new ApplicationPerformanceGraphView({
		model : graphApplicationPerformanceModel
	})

	
	
	
	var applicationPerformanceCountSelectTemplate = $("#appPerformance1_select_template").html() ; 

	var ApplicationPerformanceCountSelectSelect = Backbone.View.extend({

				el : '#appPerformance1_select',
				initialize : function() {
					// first time rendering
					this.model.refreshApplicationPerformanceData();
					this.render();
				},

				render : function() {
					console.log('-- creating drop down :  applicationPerformanceCountSelect --')
					this.$el.html(_.template(applicationPerformanceCountSelectTemplate))
				},
				
				events : {
					'change' : function(){
						this.model.set('historicalDataDayCount' , $('#appPerformance1_lastNDaysSelect').val());
						//console.log('option changed'+ this.model.get('historicalDataDayCount')) ; 
						this.model.trigger('refreshApplicationPerformanceDataEvent') ; 
					}
				}
			});
	
	
	var applicationPerformanceCountSelectSelect = new ApplicationPerformanceCountSelectSelect({
		model : graphApplicationPerformanceModel ,
	});
	


	
	
	
	
}
