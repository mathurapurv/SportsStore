/**
 * 
 */

function generateTriggerMetricesDOM() {
	// define model for graph data 
	var LetterSpecificTriggerDistributionModel = Backbone.Model.extend({
		defaults : {
			historicalDataDayCount : 1,
			data : []
		},
		initialize : function() {
			console.log('Initialize model ')
			// event handler when graph needs to be refreshed
			this.on('refreshDataEvent', function() {
				console.log('change model1 ')
				this.refreshData();
			}, this);
		},
		urlRoot : letterSpecificTriggerDetailsURL,
		
		refreshData : function(){
			this.url = this.urlRoot + this.get('historicalDataDayCount') ;
			this.fetch({
				success : function() {
					graphView.render();
				},
				error : function(error) {
					console.log('Fetch fail ');
					alert('Unable to fetch data for graph')
				}
			});
		}

	});

	var graphModel = new LetterSpecificTriggerDistributionModel({});
	
	var LetterSpecificTriggerDistributionGraphView = Backbone.View
			.extend({
				el : '#tdist1',
				initialize : function(options) {
					this.data = options.data;
				},
				render : function() {
					
					var graphData = seperateXandYaxisDatafromJSONResponse(
							this.model.get('data'), "code",
					"count") ; 
					
					this.$el
							.highcharts({
								chart : {
									type : 'column'
								},
								title : {
									text : 'Trigger distribution',
									x : -20
								},
								subtitle : {
									text : 'Letter Specific ',
									x : -20
								},
								xAxis : {
									categories : graphData.XaxisDataList
								},
								yAxis : {
									title : {
										text : 'Number of Triggers'
									},
									plotLines : [ {
										value : 0,
										width : 1,
										color : '#808080'
									} ]
								},

								legend : {
									layout : 'vertical',
									align : 'right',
									verticalAlign : 'middle',
									borderWidth : 0
								},
								series : [ {
									name : 'Count',
									data : graphData.YaxisDataList
								} ] , 
								
						        tooltip: {
						            shared: false,
						            useHTML: true,
						            formatter: function() { setTimeout( function() {
					                    $("#hc-tooltip").highcharts({
					                        chart: {
					                            plotBackgroundColor: null,
					                            plotBorderWidth: null,
					                            plotShadow: false,
					                            type: 'pie'
					                        },
					                        title: {
					                            text: 'Status report'
					                        },
					                        tooltip: {
					                         enabled: false,
					                            
					                        },
					                        plotOptions: {
					                            pie: {
					                                allowPointSelect: true,
					                                cursor: 'pointer',
					                                dataLabels: {
					                                    enabled: true,
					                                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
					                                    style: {
					                                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
					                                    }
					                                }
					                            }
					                        },
					                        series: [{
					                            name: 'Brands',
					                            colorByPoint: true,
					                            data: [{
					                                name: 'Finished',
					                                y: 56.33
					                            }, {
					                                name: 'In Progress',
					                                y: 24.03,
					                                sliced: true,
					                                selected: true
					                            }, {
					                                name: 'Failed',
					                                y: 10.38
					                            }]
					                        }]
					                    });
					                }, 10)
					                
					                return '<div id="hc-tooltip"></div>';
						            }
						        }
							});
				}
			});

	var graphView = new LetterSpecificTriggerDistributionGraphView({
		model : graphModel
	})

	var letterSpecificTriggerDistributionDayCountSelectTemplate = $("#tdist1_select_template").html() ; 

	var LetterSpecificTriggerDistributionDayCountSelect = Backbone.View.extend({

				el : '#tdist1_select',
				initialize : function() {
					// first time rendering
					this.model.refreshData();
					this.render();
				},

				render : function() {
					console.log('-- creating drop down --')
					this.$el.html(_.template(letterSpecificTriggerDistributionDayCountSelectTemplate))
				},
				
				events : {
					'change' : function(){
						this.model.set('historicalDataDayCount' , $('#lastNDaysSelect').val());
						this.model.trigger('refreshDataEvent') ; 
					}
				}
			});
	
	
	var letterSpecificTriggerDistributionDayCountSelect = new LetterSpecificTriggerDistributionDayCountSelect({
		model : graphModel ,
	});
	

}