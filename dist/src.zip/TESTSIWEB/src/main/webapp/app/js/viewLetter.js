/**
 * 
 */

function generateletterFromTH() {
	
	var GenerateTHLetterModel = Backbone.Model.extend({
		
		defaults : {
			eventId : ''
		},
		
		initialize : function() {
			
			this.on('change:eventId' , function() {
				console.log('change GenerateTHLetterModel :  '+this.get('eventId'))
				
				$.ajax({
					
					url : viewLetterEventIdURL , 
					
					
					
				})
				
				
				
				
				
				
				
				
				
				
			}, this);
			
			
		}
		
		
		
	});
	
	
	var viewLetterModel = new GenerateTHLetterModel();
	
	
	var GenerateTHLetterView = Backbone.View.extend({
		
		
		el : '#letterGenerationFormDiv',
		templateId : 'viewletter_form_template',
		
		
		initialize : function() {
			this.render();
		},
		
		render : function() {
			this.$el.html(_.template($("#"+this.templateId).html()))
		},
		
		events : {
			'click' : function(){
				console.log('eventId submitted :'+  $("#letterGenEventId").val());
				this.model.set('eventId' , $("#letterGenEventId").val()  ) ; 
				
			}
		}
		
		
		
	});
	
	var generateLetterView = new GenerateTHLetterView({
		model : viewLetterModel,
		defaults : {
			
		}
		
	});
	
	
	
	
}