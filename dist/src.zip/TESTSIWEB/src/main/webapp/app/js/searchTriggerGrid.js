/**
 * 
 */

function generateSearchTriggerDOM() {
	var SearchResultModel = Backbone.Model.extend({});

	var SearchInputParamModel = Backbone.Model.extend({
		defaults : {
			cdb : '',
			eventId : '',
			source : '',
			commCode : '',
			fromDate : '',
			toDate : '',
			searchResult : []
		},

		initialize : function() {
			console.log('Initialize model ')

			this.on('change', function() {
				console.log('change model1 ')
			}, this);
		},
		url : triggerSearchURL,
	});

	var searchFields = [ {
		name : "cdb",
		label : "CDB",
		control : "input",
		disabled : false
	}, {
		name : "eventId",
		label : "Event ID",
		control : "input",
		disabled : false
	},

	{
		name : "source",
		label : "Source",
		control : "select",
		options : generateDropDownListModel(sourceList, true),
	},

	{
		name : "commCode",
		label : "Letter Code",
		control : "select",
		options : generateDropDownListModel(letterTypeList, true),
	},

	{
		control : "button",
		label : "Submit"
	}

	];

	var searchModel = new SearchInputParamModel();

	var searchForm = new Backform.Form({
		el : $("#searchForm"),
		model : searchModel,
		fields : searchFields,
		events : {
			"submit" : function(e) {
				// prevent actual HTTP form submission
				e.preventDefault();
				searchModel.fetch({
					data : {
						cdb : JSON.stringify(this.model.get("cdb")),
						eventId : JSON.stringify(this.model.get("eventId")),
						source : JSON.stringify(this.model.get("source")),
						commCode : JSON.stringify(this.model.get("commCode")),
						fromDate : JSON.stringify(this.model.get("fromDate")),
						toDate : JSON.stringify(this.model.get("toDate"))
					},
					type : 'POST',
					success : function() {
						console.log('Fetch successful ')
						var scoll = new SearchResultCollection(searchModel
								.get('searchResult'))
						// Initialize a new Grid instance
						var searchResultGrid = new Backgrid.Grid({
							columns : searchResultColumns,
							collection : scoll
						});
						$("#searchResultGrid").empty();
						$("#searchResultGrid").append(
								searchResultGrid.render().el);
						console.log('Render complete ');
					},
					error : function(error) {
						console.log('Fetch fail ');
						alert('Unable to fetch data')
					}
				});
				// TODO : add server calling here using
				// http://stackoverflow.com/questions/6428823/backbone-js-fetch-a-collection-using-post
				return false;
			}
		}
	});

	searchForm.render();

	var searchResultColumns = [

	{
		name : "eventId",
		label : "Event ID",
		editable : false,
		cell : Backgrid.IntegerCell.extend({
			orderSeparator : ''
		})
	}, {
		name : "cdb",
		label : "CDB",
		editable : false,
		cell : Backgrid.IntegerCell.extend({
			orderSeparator : ''
		})
	}, {
		name : "accountNum",
		label : "Account Number",
		cell : "string"
	}, {
		name : "source",
		label : "Source",
		cell : "string"
	}, {
		name : "commCode",
		label : "Letter Code",
		cell : "string"
	}, {
		name : "triggerTime",
		label : "Trigger Time",
		cell : "string"
	}, {
		name : "status",
		label : "STATUS",
		cell : "string"
	} ];

	var SearchResultCollection = Backbone.Collection.extend({
		model : SearchResultModel,
		initialize : function(models, options) {
		}
	});

}